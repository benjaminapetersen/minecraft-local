BlueNerd Vanilla Plus

1.16 Updates




Changelog (V1.1)

Changed Bricks
Changed Fern/Large Fern
Changed Tall Grass
Changed Gravel
Changed Lily Pad
Changed Granite (colors only)
Changed Polished Granite
Changed Polished Diorite
Changed Trapdoors (Spruce/Oak/Jungle/Dark Oak/Acacia)
Changed Doors (Spruce/Jungle)

A Little Taste of Jerm Updates 
==========================================================
Textures borrowed from other packs(with permission):
Bdoubleo's Resource Pack: Smooth Sandstone, Bricks, End Stone Bricks, and Iron Block.
Rukbukus's Resource Pack: Sandstone, Wheat and Flowers(Slightly Edited).
The Excalibur Resource Pack by Maffhew: Wheat textures/models https://www.planetminecraft.com/texture_pack/110-excalibur/
Parrot textures created by Rukbukus and myself for both of our resource packs.
Glazed Terracotta textures inspired by Conquest by MonsterFish.

==========================================================
Changelog (V2.0)
Redid all textures to be less blurry/noisy
New White, Orange, and Green glass
New Sunflower, Peony, Lilac, and Rose Bush
Changed Biome Colors
Changed Beetroot/Rice to Corn
Changed End Stone Bricks Stairs & Slabs to Thatch
Changed Wall model
Changed Rain Sound to vanilla
Changed Brown Glass to Net texture
Changed Plank Style
Changed Potted Red Mushroom to Ink & Quill
Removed Sandstone Variants	
New Wood double slab designs
New Sandstone double slabs
New Melon/Pumpkin stems	
New GUIs
New Wandering Trader/Llama
New Iron Golems
New Smooth Stone Textures
Reset Regular Glass textures to vanilla

Changelog (V1.9.3)
Changed Dragon Egg texture
Slightly changed colormap for Spruce Leaves
Slightly changed Red Mushroom
Slightly changed Flower Pot models
Fixed Cake cullfacing
Fixed Snow Blocks & Layers being wrong textures

Changelog (V1.9.2)
New Campfire model & textures
New Composter
New Cake Variants
New Pumpkin Pie item texture
Biome dependent Snow Layers (Require Optifine) Hay layers - Plains, Forest, and Taiga. Sand layers - Desert and Beach. Red Sand layers - Mesa. Mud/Soul Sand layers - Swamp.
Removed some unused textures
Removed custom Dead Coral textures

Changelog (V1.9.1)
Changed Mushroom Fields Grass & Foliage colors
Fixed Cartography Table
Fixed Beetroot (Rice) names
Fixed chain for End Rod
Reverted Stonecutter
Reverted Brown Mushroom

Changelog (V1.9)
New texture for Alliums in flower pots
New model for flower pot when Wither Rose is in one
New model for flower pot when Brown Mushroom is in one
New Cactus
New Scaffolding
New Red Sandstone
New Hopper
New Vanilla Lantern
New Lectern
New Bell block & item
New Blast Furnace
New Barrel
New Cartography Table
New Smoker
New Smithing Table
New Chipped & Damaged Anvils
New Activator Rails(Rope & Chain)
New Cats
New Peony, Rose Bush, and Lilac
New Yellow Stained Glass
New Noteblock
New Sand/Sandstone
New Granite
New Birch Planks
New Logs and Stripped Logs
New Dirt, Coarse Dirt, Gravel, Podzol, Farmland, Soul Sand, and Mycelium
New Stone and Bedrock
New Smooth Quartz and Smooth Red Sandstone
New Grindstone
New Fletching Table
New Berries and Berry Bushes
New Flowers
New End Rods
New Lanterns
New Horses and Horse Armor
New Textures for most Double Slabs(Oak, Spruce, Birch, Jungle, Acacia, Dark Oak, Mossy & Regular Stone Bricks, Rough & Polished Andesite, Polished Diorite, Rough & Polished Granite, Mossy & Regular Cobblestone, Bricks, Nether Bricks, Quartz, Purpur, and Prismarine. 
Changed End Stone Brick Wall to Oak Log Wall
Changed Prismarine Wall to use Prismarine Brick Texture
Changed all other trapdoors to match Spruce Trapdoors

Changed Dead Horn Coral to Hanging Fish
Changed Dead Brain Coral to Smoke
Changed Dead Fire Coral Fan to Hanging Flowers/Bushes
Changed Potted Brown Mushroom to Water Bucket

Changelog (V1.8.1)
New Sunflower Item & Plant
Small Color Changes to Rose Bush, Lilac, and Peony

Changelog (V1.8)
New Iron Bars
New Coarse Dirt
New Grass Path Block
New Petrified Oak Slab(Coarse Dirt Slab)
New Diorite
New Wool Colors
New Purpur
New Sand/Sandstone
New End Stone, End Frame, & End Stone Bricks
New Seagrass Texture
New Ice, Packed Ice, Frosted Ice and Blue Ice
New Pink, Light Gray, Red, and Yellow glass
New Allium
New Obsidian
New Fern
New Potato Crop
New Potion Effect Icons(Mostly from Jappa's pack)
New Chestplate items
New Leather Armor Items
New Potato, Baked Potato, and Poisonous Potato items
New Swords
New Egg
New Farmland
New Smooth Quartz
New Brown Bed(Wooden Bench)
New Light Gray Bed(Stone Bench)
Fixed Smooth Stone Blocks
Reverted Acacia Logs
Added Haybale head to armor stand
Removed the bevel around stripped logs
Slightly changed Andesite
Slightly changed Birch colors
Slightly changed Stripped Dark Oak
Slightly changed Sponges
Slightly changed Shears(darkened iron)
Slightly changed Flint & Steel
Animated Lantern Texture
Edited Dirt, Podzol, Coarse Dirt, Grass Block, Grass Path, and Mycelium to look a bit more like vanilla

Made Custom Mob Model Add-on

For 1.14:
Added New Flowers
Added New Signs
Added Crossbow
Added New Dyes
Added Illager Beast
Added Pandas
Added Bamboo Textures

Changelog (V1.7)
New Logo!
New Wood colors & Planks
New Squid Textures
New Fish Item Textures
New Villager Textures(WIP)
New Witch Texture
New Illager Textures(Vindicator, Evoker, Illusioner)
New Zombie & Husk Variants
New Phantom Texture
New Beacon Texture
New Brown, Orange, Pink, Purple, Red, Yellow, Light Blue, Magenta, Green, Light Gray, Lime, White, and Cyan Glazed Terracotta
New Birch Logs
New Bricks, Flower Pot, Red Nether Bricks, Red Sandstone, and Red Sandstone Variants.
New Prismarine, Prismarine Bricks, & Dark Prismarine
New Nether Bricks
New Dead Horn Coral Fan
New Door Item Textures
New Carrot & Golden Carrot textures
New Chests(Inspired by Bdubs' Chests)
New Enchanting Table & Enchanting Table Particles
New Crafting Table
New Map icons(White, Orange, Yellow, Light Gray, Purple, Brown, & Black)
New Painting Item & 2 new Painting Variations
New Redstone Torch(Candle) Model
Changed Wheat Colors(Crop, item, Hay Bale)
Reverted all Dye textures to 1.12 versions
Reverted Water to old water texture(may not stay)
Fixed Water & Lava animations
Updated some of the Advancement Textures to match the block textures
Slightly changed Acacia Logs(Rotated to match Jungle Logs)
Slightly changed Bone Block
Slightly changed Jungle Leaves
Slightly changed Light Gray wool & Cyan wool
Removed Bushy Leaves(Moved to it's own add-on)
Removed a lot of unedited default textures
Updated most of the Optifine features

Changelog (V1.6)
Changed Dead Horn Coral Fan to look like a Bird's Nest
Changed Glowstone (may change again in the future)
Fixed bottom of Sandstone corner stair

Changelog (V1.5)
Updated to 1.13
Fixed Armor
Fixed Redstone Lamp?
Fixed Quartz Block
Fixed Cauldron
Slightly changed Dark Oak, Spruce, Oak, Acacia, and Birch Leaves
Changed Jungle Leaves to new default textures
Recolored Dead Coral Fans

Changelog (V1.4)
Fixed Lit Furnace texture not being animated
Fixed Jack O' Lantern and Pumpkin face textures
Fixed Redstone Lamp
Fixed Bark Block textures

Changelog (V1.3)
Changed Menu Background
Fixed white pixel on Iron Helmet
Update to work with Pre-release 3

Changelog (V1.2)
New Nether Wart Item
New Minecart item and entity textures
New Ice & Packed Ice
New Log Tops & Stripped Log Tops
Slightly changed the fish buckets
Slightly changed Carrot on a Stick
Slightly changed Bookshelves
Slightly changed Phantom Membrane
Changed Stone Brick, Andesite Brick, Granite Brick, and Diorite Brick overlays
Changed End Stone, End Stone Bricks, End Portal Frame, Eye of Ender, and Ender Pearl
Changed Brown Mushroom item & block.
Changed Repeater and Comparator items
Changed Dried Kelp item
Changed Azure Bluet, Blue Orchid, and Allium
Changed Egg
Changed Trip Wire Hook
Changed Bowl, Mushroom Stew, and Rabbit Stew
Changed Oxeye Daisy
Changed Snow Block
Changed Netherrack & Nether Quartz Ore
Changed Water back to default for 1.13

Changelog (V1.1)
Added a bunch of the new default textures
Changed Path Block textures
Slight edit to Acacia Leaves
Slight edit to Dark Oak Leaves and Sapling
Fixed some issues with overlays and shaders
Fixed some issues with grass from Biomes O' Plenty
Fixed Cyan Carpet Model

Changelog 4/19/2018 (V1.0)
Completely changed Red Sand, and Sandstone to blend with the brick colors
Changed Sea Pickles that are not in water to look like Candles
Added the new vanilla Fern, Tall Fern, new Stone Brick types as variations
Changed the bookshelves to match a bit better
Changed Red Nether Brick
Changed Oak, Dark Oak, Spruce, and Birch Leaves
Changed the Spruce Sapling
Slightly changed the color of Diamond and Gold, and added in the new default armor textures
Changed the Fish item textures
Changed pork, golden apples, apple, cake, chicken, beef, potato, rabbit, and mutton textures
Desaturated all the stone, stone brick, and cobblestone blocks
Changed Blue Ice
Changed the Purple wool, dye, concrete, and bed
Changed Magenta Wool
Changed Sand Color, and Sandstone Textures
Changed Bucket Textures
Changed biome colors back to vanilla colors
Changed Terracotta and Stained Terracottas
Changed Double Tall Grass
Changed Oak, Spruce, Birch, and Dark Oak Saplings
Slightly Changed dirt, and other dirt related blocks
Added Dolphins
Added Turtles
Added Turle Eggs
Added Kelp
Added Seagrass
Added all Stripped Log variants
Added New Spruce Leaves Textures